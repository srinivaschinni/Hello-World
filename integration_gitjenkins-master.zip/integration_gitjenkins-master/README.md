# Tibco BusinessWorks, GIT and Jenkins  

Test repo for a integration proof of concept of bw, git and jenkins.  
This is a sample service which can be build by buildear and deployed by appmanage (both CLI TIBCO Tools for automation).  
It is used for my blog post to demonstrated automated build & deployment of Tibco BW 5.12 process.
